#Filtering function, assumes labels "REF", "TOTAL", "A/C/T/G.count"
#Filtering criteria: A/T reference, in REDIportal, >3 reads, <.99 editing, not .5 editing
filter_ADAR <- function(reads, reference){
  
  #Select ADAR editing sites
  filtered <- filter(reads, REF == "T" | REF == "A")
  #attach editing frequency column
  filtered <- mutate(filtered, Editing.rate = 0)
  #Calculate editing frequency for each site: distinguishes between A->G and T->c
  for (n in 1:nrow(filtered)){
    if (filtered$REF[n] == "A"){
      filtered$Editing.rate[n] = filtered$G.count[n]/filtered$TOTAL[n]
    }
    else{
      filtered$Editing.rate[n] = filtered$C.count[n]/filtered$TOTAL[n]
    }
  }
  
  
  filtered <- filter(filtered, POS %in% reference)
  filtered <- filter(filtered, TOTAL >= 3)
  filtered <- filter(filtered, Editing.rate <= .99 & Editing.rate >= 0.01)
  filtered <- filter(filtered, Editing.rate <= .49 | Editing.rate >= 0.51)
  
  return(filtered)
}

#Function to add the average editing rate for each sample
editing_Average <- function(sample_List, sample_Data){
  y <- ncol(sample_Data) + 1
  Editing.average <- vector()
  for(m in 1:length(sample_List)){
    a <-  mean(sample_List[[m]]$Editing.rate)
    Editing.average <- c(Editing.average, a)
    
  }
  sample_Data <- cbind(sample_Data, Editing.average)
  
  return(sample_Data)
}




#Input a list containing each sample's editing sites, and a vector with each unique coordinate tested
#Output is a dataframe with editing rates in each sample for each coordinate (with sites with no variants detected automatically given as 0)
Site_sample_table <- function(Sample_list, Sites){
  zero <- rep(0,length(Sites))
  
  for(n in 1:length(Sample_list)){
    Sites <- data.frame(Sites,zero)
    
  }
  colnames(Sites) <- c("POS", names(Sample_list))
  
  for(n in 1:nrow(Sites)){
    for(m in 1:length(Sample_list)){
      if(Sites$POS[n] %in% Sample_list[[m]]$POS){
        Sites[n, m+1] <- Sample_list[[m]]$Editing.rate[match(Sites$POS[n], Sample_list[[m]]$POS)]
      } 
    }
  }
  
  return(Sites)
}




#Input a dataframe with editing rates for each sample per coordinate (as per the Site_sample_table() function)
#Adds a column with 
Diff_editing_t <- function(Site_editing){
  Site_editing <- mutate(Site_editing, p.value = 1)
  for(n in 1:nrow(Site_editing)){
    Site_editing$p.value[n] <- t.test(Site_editing[n, 2:4], Site_editing[n, 5:7])$p.value
  }
  Site_editing$p.value <- p.adjust(Site_editing$p.value, method='fdr')
  
  
  return(Site_editing)
}

















#Reformats files to get numeric count values, assuming dataframe columns are labelled "A.count" "C.count" "G.count" and "T.count"
get_counts <- function(counts){
  for(n in 1:nrow(counts)){
    counts$A.count[n] <- str_split_fixed(counts$A.count[n], ":", n = 3)[2]
    counts$C.count[n] <- str_split_fixed(counts$C.count[n], ":", n = 3)[2]
    counts$G.count[n] <- str_split_fixed(counts$G.count[n], ":", n = 3)[2]
    counts$T.count[n] <- str_split_fixed(counts$T.count[n], ":", n = 3)[2]
  }
  counts$A.count <- as.numeric(counts$A.count)
  counts$C.count <- as.numeric(counts$C.count)
  counts$G.count <- as.numeric(counts$G.count)
  counts$T.count <- as.numeric(counts$T.count)
  return(counts)
}





Diff_editing_t_pairwise <- function(Site_editing){
  Site_editing <- mutate(Site_editing, p.Control_ZIKV_FSS = 1)
  Site_editing <- mutate(Site_editing, p.Control_ZIKV_PE = 1)
  Site_editing <- mutate(Site_editing, p.ZIKV_FSS_ZIKV_PE = 1)
  
  conditions <- c("ZIKV_PE","ZIKV_FSS","ZIKV_FSS","ZIKV_PE","ZIKV_PE","Control","Control","Control","ZIKV_FSS")
  
  
  
  for(n in 1:nrow(Site_editing)){
    control <- Site_editing[n,c(7,8,9)]
    ZIKV_FSS <- Site_editing[n,c(3,4,10)]
    ZIKV_PE <- Site_editing[n,c(2,5,6)]
    
    Site_editing$p.Control_ZIKV_FSS[n] <- t.test(control,ZIKV_FSS)$p.value
    Site_editing$p.Control_ZIKV_PE[n] <- t.test(control,ZIKV_PE)$p.value
    Site_editing$p.ZIKV_FSS_ZIKV_PE[n] <- t.test(ZIKV_FSS,ZIKV_PE)$p.value
  }
  
  Site_editing[,11:13] <- Site_editing[,11:13] %>% as.matrix %>% as.vector %>% p.adjust(method='fdr') %>% matrix(ncol=3) %>% as.data.frame
  
  return(Site_editing)
}















