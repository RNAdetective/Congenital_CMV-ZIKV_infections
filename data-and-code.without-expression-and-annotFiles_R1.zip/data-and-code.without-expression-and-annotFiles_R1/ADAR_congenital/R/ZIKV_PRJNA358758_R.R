library(ggplot2)
library(ggsignif)
library(dplyr)
library(stringr)
library(DESeq2)
source("R/editing_functions.R")


#Set working directory to "ADAR_congenital" project folder
setwd()


#=================Data processing and analysis==========================================


#Read REDIportal variant data
REDIportal <- read.delim("data/TABLE1_mm10.txt")
#Only non-dbsnp sites
REDIcoordinates <- filter(REDIportal, dbsnp == "-")
#Create a list of these coordinates, reference RNA editing sites
REDIcoordinates <- data.frame(REDIcoordinates$Region, REDIcoordinates$Position)


#Create files of variant frequency counts for each sample
#Add labels for sample ID and infection condition
Control_counts_1 <- read.csv("data/frequency_counts/ZIKV_358758/SRR5136882All.csv")
Control_counts_1 <- data.frame(Control_counts_1, Sample = rep("SRR5136882",nrow(Control_counts_1)), Infection = rep("Control",nrow(Control_counts_1)))
names(Control_counts_1) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count","Sample","Infection")
Control_counts_1 <- filter_ADAR(Control_counts_1, REDIcoordinates$REDIcoordinates.Position)

Control_counts_2 <- read.csv("data/frequency_counts/ZIKV_358758/SRR5136883All.csv")
Control_counts_2 <- data.frame(Control_counts_2, Sample = rep("SRR5136883",nrow(Control_counts_2)), Infection = rep("Control",nrow(Control_counts_2)))
names(Control_counts_2) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count","Sample","Infection")
Control_counts_2 <- filter_ADAR(Control_counts_2, REDIcoordinates$REDIcoordinates.Position)

Control_counts_3 <- read.csv("data/frequency_counts/ZIKV_358758/SRR5137136All.csv")
Control_counts_3 <- data.frame(Control_counts_3, Sample = rep("SRR5137136",nrow(Control_counts_3)), Infection = rep("Control",nrow(Control_counts_3)))
names(Control_counts_3) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count","Sample","Infection")
Control_counts_3 <- filter_ADAR(Control_counts_3, REDIcoordinates$REDIcoordinates.Position)

ZIKV_counts_1 <- read.csv("data/frequency_counts/ZIKV_358758/SRR5137139All.csv")
ZIKV_counts_1 <- data.frame(ZIKV_counts_1, Sample = rep("SRR5137139",nrow(ZIKV_counts_1)), Infection = rep("ZIKV",nrow(ZIKV_counts_1)))
names(ZIKV_counts_1) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count","Sample","Infection")
ZIKV_counts_1 <- filter_ADAR(ZIKV_counts_1, REDIcoordinates$REDIcoordinates.Position)

ZIKV_counts_2 <- read.csv("data/frequency_counts/ZIKV_358758/SRR5137142All.csv")
ZIKV_counts_2 <- data.frame(ZIKV_counts_2, Sample = rep("SRR5137142",nrow(ZIKV_counts_2)), Infection = rep("ZIKV",nrow(ZIKV_counts_2)))
names(ZIKV_counts_2) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count","Sample","Infection")
ZIKV_counts_2 <- filter_ADAR(ZIKV_counts_2, REDIcoordinates$REDIcoordinates.Position)

ZIKV_counts_3 <- read.csv("data/frequency_counts/ZIKV_358758/SRR5137144All.csv")
ZIKV_counts_3 <- data.frame(ZIKV_counts_3, Sample = rep("SRR5137144",nrow(ZIKV_counts_3)), Infection = rep("ZIKV",nrow(ZIKV_counts_3)))
names(ZIKV_counts_3) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count","Sample","Infection")
ZIKV_counts_3 <- filter_ADAR(ZIKV_counts_3, REDIcoordinates$REDIcoordinates.Position)


#Combine the above datasets into a single dataframe
ADAR_sites <- rbind(Control_counts_1,Control_counts_2,Control_counts_3,ZIKV_counts_1,ZIKV_counts_2,ZIKV_counts_3)




#Add site annotations from REDIportal
names(REDIportal)[2] <- "POS"
REDIportal <- REDIportal[,c(2,5,9,10,11)]
ADAR_sites <- left_join(ADAR_sites,REDIportal,by="POS")

#Create a dataframe to store whole-sample statistics
Sample_data <- data.frame(Sample = c("SRR5136882","SRR5136883","SRR5137136","SRR5137139",
                                     "SRR5137142","SRR5137144"), Infection = c("Control",
                                                                               "Control","Control","ZIKV","ZIKV","ZIKV"))
#Add average editing rate to sample data
Sample_list <- split(ADAR_sites,ADAR_sites$Sample)
Sample_data <- editing_Average(Sample_list,Sample_data)

#Add number of editing sites to sample data
Sample_data <- data.frame(Sample_data, Editing.sites = summary(as.factor(ADAR_sites$Sample)))

















#================================EXPRESSION====================================================

#Create files of TPM expression values for each sample
#Add labels for sample ID and infection condition
Control_1 <- read.table("data/expression/ZIKV_358758/SRR5136882.tab", sep="\t", header=TRUE)
Control_1 <- Control_1[!duplicated(Control_1$Gene.ID), ]
Control_1 <- Control_1[!duplicated(Control_1$Gene.Name), ]
Control_1 <- data.frame(Control_1, Sample = rep("SRR5136882",nrow(Control_1)), Infection = rep("Control",nrow(Control_1)))


Control_2 <- read.table("data/expression/ZIKV_358758/SRR5136883.tab", sep="\t", header=TRUE)
Control_2 <- Control_2[!duplicated(Control_2$Gene.ID), ]
Control_2 <- Control_2[!duplicated(Control_2$Gene.Name), ]
Control_2 <- data.frame(Control_2, Sample = rep("SRR5136883",nrow(Control_2)), Infection = rep("Control",nrow(Control_2)))


Control_3 <- read.table("data/expression/ZIKV_358758/SRR5137136.tab", sep="\t", header=TRUE)
Control_3 <- Control_3[!duplicated(Control_3$Gene.ID), ]
Control_3 <- Control_3[!duplicated(Control_3$Gene.Name), ]
Control_3 <- data.frame(Control_3, Sample = rep("SRR5137136",nrow(Control_3)), Infection = rep("Control",nrow(Control_3)))


ZIKV_1 <- read.table("data/expression/ZIKV_358758/SRR5137139.tab", sep="\t", header=TRUE)
ZIKV_1 <- ZIKV_1[!duplicated(ZIKV_1$Gene.ID), ]
ZIKV_1 <- ZIKV_1[!duplicated(ZIKV_1$Gene.Name), ]
ZIKV_1 <- data.frame(ZIKV_1, Sample = rep("SRR5137139",nrow(ZIKV_1)), Infection = rep("ZIKV",nrow(ZIKV_1)))


ZIKV_2 <- read.table("data/expression/ZIKV_358758/SRR5137142.tab", sep="\t", header=TRUE)
ZIKV_2 <- ZIKV_2[!duplicated(ZIKV_2$Gene.ID), ]
ZIKV_2 <- ZIKV_2[!duplicated(ZIKV_2$Gene.Name), ]
ZIKV_2 <- data.frame(ZIKV_2, Sample = rep("SRR5137142",nrow(ZIKV_2)), Infection = rep("ZIKV",nrow(ZIKV_2)))


ZIKV_3 <- read.table("data/expression/ZIKV_358758/SRR5137144.tab", sep="\t", header=TRUE)
ZIKV_3 <- ZIKV_3[!duplicated(ZIKV_3$Gene.ID), ]
ZIKV_3 <- ZIKV_3[!duplicated(ZIKV_3$Gene.Name), ]
ZIKV_3 <- data.frame(ZIKV_3, Sample = rep("SRR5137144",nrow(ZIKV_3)), Infection = rep("ZIKV",nrow(ZIKV_3)))

#Create a combined dataframe with expression values for all samples
ZIKV_TPM_tot <- rbind(Control_1, Control_2, Control_3, ZIKV_1, ZIKV_2, ZIKV_3)


#Get ADAR1/b1/b2 expression
ADAR_TPM <- ZIKV_TPM_tot[str_which(ZIKV_TPM_tot$Gene.Name, "Adar"),]
ADAR_TPM <- split(ADAR_TPM, ADAR_TPM$Gene.Name)

#Add expression data for ADAR enzymes to sample data
ADAR_TPM[[1]] <- ADAR_TPM[[1]][,c(9,10)]
ADAR_TPM[[2]] <- ADAR_TPM[[2]][,c(9,10)]
ADAR_TPM[[3]] <- ADAR_TPM[[3]][,c(9,10)]
names(ADAR_TPM[[1]])[1] <- "Adar1.TPM"
names(ADAR_TPM[[2]])[1] <- "Adarb1.TPM"
names(ADAR_TPM[[3]])[1] <- "Adarb2.TPM"
Sample_data <- left_join(Sample_data, ADAR_TPM[[1]], by = "Sample")
Sample_data <- left_join(Sample_data, ADAR_TPM[[2]], by = "Sample")
Sample_data <- left_join(Sample_data, ADAR_TPM[[3]], by = "Sample")








#================================STATS====================================================
#Find sites with differential editing
coordinates <- ADAR_sites$POS[!duplicated(ADAR_sites$POS)]
Site_editing <- Site_sample_table(Sample_list, coordinates)
Site_editing <- Diff_editing_t(Site_editing)
Site_editing <- left_join(Site_editing,REDIportal,by="POS")
Site_editing <- left_join(Site_editing, ADAR_sites[,1:3],by = "POS")
Site_editing <- Site_editing[!duplicated(Site_editing$POS), ]
Sig_sites <- filter(Site_editing, p.value <= 0.05)
Sig_sites <- mutate(Sig_sites, Editing_change = ((SRR5137139 + SRR5137142 + SRR5137144)-(SRR5136882 + SRR5136883 + SRR5137136))/3)


#ADAR1 expression
t.test(Sample_data$Adar1.TPM[1:3], Sample_data$Adar1.TPM[4:6])

#ADARb1 expression
t.test(Sample_data$Adarb1.TPM[1:3], Sample_data$Adarb1.TPM[4:6])

#ADARb2 expression
t.test(Sample_data$Adarb2.TPM[1:3], Sample_data$Adarb2.TPM[4:6])

#Site number
t.test(Sample_data$Editing.sites[1:3], Sample_data$Editing.sites[4:6])

#Average rate
t.test(Sample_data$Editing.average[1:3], Sample_data$Editing.average[4:6])


# DESeq2
#Gene counts
# Read in count matrix from ballgown
gene_counts  <- read.csv("data/ballgown_counts/deseq2_PRJNA358758.mouse-ZIKV/gene_count_matrix.csv", header=T, row.names=1) 
# create experiment labels 
study_countsLabels <- read.csv("data/ballgown_counts/deseq2_PRJNA358758.mouse-ZIKV/PHENO_DATA.PRJNA358758.csv", header=T, row.names=1)
# create DESeq input matrix  
dds_study_gene <- DESeqDataSetFromMatrix(countData=gene_counts, colData = study_countsLabels, design = ~condition)
dds_gene <- DESeq(dds_study_gene)
res_gene <- results(dds_gene)
#Transcript counts
# Read in count matrix from ballgown
transcript_counts  <- read.csv("data/ballgown_counts/deseq2_PRJNA358758.mouse-ZIKV/transcript_count_matrix.csv", header=T, row.names=1) 
# create DESeq input matrix  
dds_study_transcript <- DESeqDataSetFromMatrix(countData=transcript_counts, colData = study_countsLabels, design = ~condition)
dds_transcript <- DESeq(dds_study_transcript)
res_transcript <- results(dds_transcript)



#RNA Editing Indexing
AEI_out <- read.csv("data/RNA_editing_index/ZIKV358758_EditingIndex.csv")
Sample_data <- left_join(Sample_data, AEI_out, by="Sample")
t.test(Sample_data$A2GEditingIndex[1:3], Sample_data$A2GEditingIndex[4:6])




#================================PLOTS====================================================

#FIGURE 11
#Expression
ADAR1_plot <- ggplot(Sample_data, aes(y = Adar1.TPM, x = Infection)) + geom_boxplot() + geom_jitter(shape=10, position=position_jitter(0.2)) + theme_classic(base_size = 25) + xlab(NULL) + ylab("Adar Expression (TPM)") + geom_signif(comparisons = list(c("Control", "ZIKV")), map_signif_level=TRUE, annotations = c("***"))
ADAR1_plot

ADAR2_plot <- ggplot(Sample_data, aes(y = Adarb1.TPM, x = Infection)) + geom_boxplot() + geom_point() + geom_jitter(shape=10, position=position_jitter(0.2)) + theme_classic(base_size = 25) + xlab(NULL) + ylab("Adarb1 Expression (TPM)") + geom_signif(comparisons = list(c("Control", "ZIKV")), map_signif_level=TRUE, annotations = c("***"))
ADAR2_plot

ADAR3_plot <- ggplot(Sample_data, aes(y = Adarb2.TPM, x = Infection)) + geom_boxplot() + geom_point() + geom_jitter(shape=10, position=position_jitter(0.2)) + theme_classic(base_size = 25) + xlab(NULL) + ylab("Adarb2 Expression (TPM)") + geom_signif(comparisons = list(c("Control", "ZIKV")), map_signif_level=TRUE, annotations = c("***"))
ADAR3_plot

#FIGURE 12
#Editing sites boxplot
Ed_site_plot <- ggplot(Sample_data, aes(y = Editing.sites, x = Infection)) + geom_boxplot()  + geom_jitter(shape=10, position=position_jitter(0.2)) + theme_classic(base_size = 25) + xlab(NULL) + ylab("Editing Sites") + geom_signif(comparisons = list(c("Control", "ZIKV")), map_signif_level=TRUE, annotations = c("***"))
Ed_site_plot

#FIGURE 13
#Editing average boxplot
Ed_ave_plot <- ggplot(Sample_data, aes(y = Editing.average, x = Infection)) + geom_boxplot()  + geom_jitter(shape=10, position=position_jitter(0.2)) + theme_classic(base_size = 25) + xlab(NULL) + ylab("Average Editing Rate") + geom_signif(comparisons = list(c("Control", "ZIKV")), map_signif_level=TRUE, annotations = c("*"))
Ed_ave_plot

#FIGURE 14
#Editing
Ed_rate_plot <- ggplot(ADAR_sites, aes(y = Editing.rate, x = Sample, color = Infection)) + geom_violin() + geom_boxplot(width=0.1) + theme_classic(base_size = 25) +ylab("Editing Rate")
Ed_rate_plot




#Editing region plot
regions <- Sig_sites %>% dplyr::count(Func.wgEncodeGencodeBasicVM16) 
regions <- regions[order(regions$n,decreasing=T),]
regions$Func.wgEncodeGencodeBasicVM16 <- c("3' UTR", "Exonic", "ncRNA Intronic", "ncRNA Exonic",  "Downstream", "Intergenic","Intronic")
regions$Func.wgEncodeGencodeBasicVM16 <- regions$Func.wgEncodeGencodeBasicVM16 %>% factor(levels = c("3' UTR", "Downstream", "Exonic", "ncRNA Exonic", "ncRNA Intronic", "Intronic", "Intergenic"))
region_plot <- ggplot(data = regions, aes(x = "", y = n, fill = Func.wgEncodeGencodeBasicVM16)) + labs(fill="Gene Region") + geom_bar(width = 1, stat = "identity") + coord_polar("y", start=0) + theme_void() + geom_text(aes(label = n), position = position_stack(vjust = 0.5))
region_plot




#RNA Editing Indexer
indeces <- Sample_data[,c("A2CEditingIndex","A2GEditingIndex","A2TEditingIndex","C2AEditingIndex","C2GEditingIndex","C2TEditingIndex")] %>% as.matrix() %>% as.vector()
variant <- c(rep("A-to-C",6),rep("A-to-G",6),rep("A-to-T",6),rep("C-to-A",6),rep("C-to-G",6),rep("C-to-T",6))

editing_index <- data.frame(Sample = rep(Sample_data$Sample, 6), Infection = rep(Sample_data$Infection, 6), 
                            Index = indeces, Variant = variant)

Ed_index_plot <- ggplot(editing_index, aes(y = Index, x = Variant, color = Infection)) + geom_boxplot() + geom_jitter(shape=10, position = position_jitterdodge(jitter.width = 0.2)) + theme_classic(base_size = 25) #+ xlab(NULL) + ylab("Editing Index") + geom_signif(comparisons = list(c("Control", "ZIKV.PE243"),c("Control", "ZIKV.FSS13205"),c("ZIKV.PE243", "ZIKV.FSS13205")), annotations = c("***","***","**")) 
Ed_index_plot



#Expression Editing correlation
colnames(Site_editing)[colnames(Site_editing) == "Gene.wgEncodeGencodeBasicVM16"] ="Gene.Name"
site_exp <- left_join(Site_editing, data.frame(Gene.Name = Control_1$Gene.Name, Control_1_TPM = Control_1$TPM), by = "Gene.Name")
site_exp <- left_join(site_exp, data.frame(Gene.Name = Control_2$Gene.Name, Control_2_TPM = Control_2$TPM), by = "Gene.Name")
site_exp <- left_join(site_exp, data.frame(Gene.Name = Control_3$Gene.Name, Control_3_TPM = Control_3$TPM), by = "Gene.Name")
site_exp <- left_join(site_exp, data.frame(Gene.Name = ZIKV_1$Gene.Name, ZIKV_1_TPM = ZIKV_1$TPM), by = "Gene.Name")
site_exp <- left_join(site_exp, data.frame(Gene.Name = ZIKV_2$Gene.Name, ZIKV_2_TPM = ZIKV_2$TPM), by = "Gene.Name")
site_exp <- left_join(site_exp, data.frame(Gene.Name = ZIKV_3$Gene.Name, ZIKV_3_TPM = ZIKV_3$TPM), by = "Gene.Name")

exp_change <- mutate(site_exp, TPM_change = ((ZIKV_1_TPM + ZIKV_2_TPM + ZIKV_3_TPM) - (Control_1_TPM + Control_2_TPM + Control_3_TPM))/3)
exp_change <- mutate(exp_change, Editing_change = ((SRR5137139 + SRR5137142 + SRR5137144)-(SRR5136882 + SRR5136883 + SRR5137136))/3)

exp_edit_plot <- ggplot(data = exp_change, aes(x = TPM_change, y = Editing_change)) + geom_point() + theme_classic() + xlab("TPM Change") + ylab("Editing Change")
exp_edit_plot


exp_edit_cor <- lm(data = exp_change, Editing_change ~ TPM_change)
summary(exp_edit_cor)



#Volcano plot
exp_change <- mutate(exp_change, logp = -log10(p.value))
vplot <- ggplot(data = exp_change, aes(x = Editing_change, y = logp, color = p.value < 0.05)) + geom_point() + theme_classic() + xlab("Change in Editing Rate") + ylab("-log(p)")  + scale_color_hue(labels = c("Significant", "Not significant"), breaks = c(TRUE, FALSE))  + labs(color = "")
vplot




































