add_biomart_data <- function(dif_sites){
  for(n in 1:nrow(dif_sites)){
    dif_site_genes <- getBM(attributes=c("ensembl_gene_id"), filters=c("chromosome_name","start","end"), values=list(dif_sites$CHR[n],dif_sites$POS[n],dif_sites$POS[n]), mart=mart)
    if (length(dif_site_genes$ensembl_gene_id) > 0){
      dif_sites$ensembl_gene_id[n] <- dif_site_genes$ensembl_gene_id[1]
    }
    else{
      dif_sites$ensembl_gene_id[n] <- ""
    }
  }
  
  dif_site_transcripts <- getBM(attributes=c("ensembl_transcript_id"), filters="ensembl_gene_id", values=dif_sites$ensembl_gene_id, mart=mart)
  dif_site_transcript_utr3 <- getBM(attributes = c("ensembl_gene_id","external_gene_name","ensembl_transcript_id","strand","start_position","end_position","transcript_start","transcript_end","3_utr_start","3_utr_end","3utr"), filters = "ensembl_transcript_id", values = dif_site_transcripts, mart = mart)
  dif_sites <- left_join(dif_sites, dif_site_transcript_utr3, by = "ensembl_gene_id")
  
  return(dif_sites)
}

in_utr <- function(biomart){
  biomart <- filter(biomart, !is.na(utr_3_seq) & utr_3_seq != "Sequence unavailable")
  biomart <- data.frame(biomart, in_utr = rep(NA, nrow(biomart)))
  biomart <- data.frame(biomart, in_gene = rep(NA, nrow(biomart)))
  biomart <- data.frame(biomart, in_transcript = rep(NA, nrow(biomart)))
  for(n in 1:nrow(biomart)){
    coord <- biomart$POS[n]
    utr_start <- as.numeric(strsplit(as.character(biomart$utr_3_start[n]), split = ';', fixed = T)[[1]])
    utr_end <- as.numeric(strsplit(as.character(biomart$utr_3_end[n]), split = ';', fixed = T)[[1]])
    
    in_coord <- F
    
    if(length(utr_end) == 1){
      in_coord <- coord > utr_start & coord < utr_end
    }
    else{
      for(i in 1:length(utr_end)){
        in_utr_i <- coord > utr_start[i] & coord < utr_end[i]
        in_coord <- in_coord | in_utr_i
      }
    }
    if(length(in_coord) > 0){
      biomart$in_utr[n] <- in_coord
    }
    
  }
  
  
  for(n in 1:nrow(biomart)){
    coord <- biomart$POS[n]
    gene_start <- as.numeric(biomart$start_position[n])
    gene_end <- as.numeric(biomart$end_position[n])
    
    in_coord <- coord > gene_start & coord < gene_end
    biomart$in_gene[n] <- in_coord
  }
  
  
  for(n in 1:nrow(biomart)){
    coord <- biomart$POS[n]
    transcript_start <- as.numeric(biomart$transcript_start[n])
    transcript_end <- as.numeric(biomart$transcript_end[n])
    
    in_coord <- coord > transcript_start & coord < transcript_end
    biomart$in_transcript[n] <- in_coord
  }
  
  return(biomart)
  
}

edit_seq <- function(dif_utrs){
  dif_utrs <- mutate(dif_utrs, edited_utr_3_seq = "")
  for(n in 1:nrow(dif_utrs)){
    coord <- dif_utrs$POS[n]
    start <- as.numeric(strsplit(as.character(dif_utrs$utr_3_start[n]), split = ';', fixed = T)[[1]])
    end <- as.numeric(strsplit(as.character(dif_utrs$utr_3_end[n]), split = ';', fixed = T)[[1]])
    seq <- dif_utrs$utr_3_seq[n] %>% as.character() %>% str_split_fixed(pattern = "", n = nchar(dif_utrs$utr_3_seq[n])) %>% as.vector() %>% as.list()
    
    
    if(length(end) == 1){
      names(seq) <- start:end
    } 
    else{
      coord_names <- vector()
      for(i in 1:length(start)){
        coord_names <- c(coord_names,start[i]:end[i])
      }
      names(seq) <- coord_names
    }
    
    edit_index <- which(names(seq) == coord)
    edit_site <- seq[[edit_index]]
    edit_seq <- dif_utrs$utr_3_seq[n]
    
    if(edit_site == "A" & edit_site == dif_utrs$REF[n]){
      substr(edit_seq, edit_index, edit_index) <- "G"
    }
    else if(edit_site == "T" & edit_site == dif_utrs$REF[n]){
      substr(edit_seq, edit_index, edit_index) <- "C"
    }
    else{
      edit_seq <- NA
    }
    dif_utrs$edited_utr_3_seq[n] <- edit_seq
    
  }
  return(dif_utrs)
}


