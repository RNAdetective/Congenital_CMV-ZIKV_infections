library(dplyr)
library(stringr)
library(biomaRt)
library(miRBaseConverter)
library(seqinr)
source("R/miRNA_functions.R")

#Set working directory to "ADAR_congenital" project folder
setwd("")


#==================================Get 3'UTR Sequences for Editing Sites==============================================

#Read in significant changing editing sites
dif_sites_ZIKV_358758 <- read.csv("output/ZIKV_358758_sites_sig.csv", header = T)
dif_sites_ZIKV_1 <- read.csv("output/ZIKV_487357_sites_sig.csv", header = T)
dif_sites_MCMV <- read.csv("output/MCMV_sites_sig.csv", header = T)

colnames(dif_sites_MCMV)[13] <- "geneName"
colnames(dif_sites_ZIKV_1)[13] <- "geneName"
colnames(dif_sites_ZIKV_358758)[13] <- "geneName"

dif_sites_ZIKV_358758$POS <- as.numeric(dif_sites_ZIKV_358758$POS)
dif_sites_ZIKV_1$POS <- as.numeric(dif_sites_ZIKV_1$POS)
dif_sites_MCMV$POS <- as.numeric(dif_sites_MCMV$POS)


#Import Biomart data
mart <- useMart(host = "https://nov2020.archive.ensembl.org/", biomart = "ensembl", dataset = "mmusculus_gene_ensembl")

#Add 3' UTR sequence and gene info
dif_sites_MCMV <- add_biomart_data(dif_sites_MCMV)
colnames(dif_sites_MCMV)[16] <- "geneId"
colnames(dif_sites_MCMV)[26] <- "utr_3_start"
colnames(dif_sites_MCMV)[17] <- "utr_3_end"
colnames(dif_sites_MCMV)[18] <- "utr_3_seq"

dif_sites_ZIKV_1 <- add_biomart_data(dif_sites_ZIKV_1)
colnames(dif_sites_ZIKV_1)[16] <- "geneId"
colnames(dif_sites_ZIKV_1)[26] <- "utr_3_start"
colnames(dif_sites_ZIKV_1)[17] <- "utr_3_end"
colnames(dif_sites_ZIKV_1)[18] <- "utr_3_seq"

dif_sites_ZIKV_358758 <- add_biomart_data(dif_sites_ZIKV_358758)
colnames(dif_sites_ZIKV_358758)[16] <- "geneId"
colnames(dif_sites_ZIKV_358758)[26] <- "utr_3_start"
colnames(dif_sites_ZIKV_358758)[17] <- "utr_3_end"
colnames(dif_sites_ZIKV_358758)[18] <- "utr_3_seq"


#Select sites in 3'UTRs
MCMV_3utr <- in_utr(dif_sites_MCMV)
ZIKV_1_3utr <- in_utr(dif_sites_ZIKV_1)
ZIKV_2_3utr <- in_utr(dif_sites_ZIKV_358758)

MCMV_3utr <- filter(MCMV_3utr, in_utr == T)
ZIKV_1_3utr <- filter(ZIKV_1_3utr, in_utr == T)
ZIKV_2_3utr <- filter(ZIKV_2_3utr, in_utr == T)




#Generate edited sequences
MCMV_3utr <- edit_seq(MCMV_3utr)
ZIKV_1_3utr <- edit_seq(ZIKV_1_3utr)
ZIKV_2_3utr <- edit_seq(ZIKV_2_3utr)

MCMV_3utr <- filter(MCMV_3utr, !is.na(edited_utr_3_seq))
ZIKV_1_3utr <- filter(ZIKV_1_3utr, !is.na(edited_utr_3_seq))
ZIKV_2_3utr <- filter(ZIKV_2_3utr, !is.na(edited_utr_3_seq))




#==================================Get miRNA Info==============================================

#Get info on which differentially edited genes are targetted by miRNA in the mouse brain
#TarBase V8 Bulk Download
TarBase <- read.delim("data/TarBase_v8_download.txt", sep = "\t", header = T)
TarBase <- filter(TarBase, species == "Mus musculus")
TarBase <- filter(TarBase, tissue == "Brain")

MCMV_TarBase <- inner_join(MCMV_3utr, TarBase, by = "geneId")
ZIKV_1_TarBase <- inner_join(ZIKV_1_3utr, TarBase, by = "geneId")
ZIKV_358758_TarBase <- inner_join(ZIKV_2_3utr, TarBase, by = "geneId")

#Get miRNA sequences from mirbase
mirbase <- read.fasta("data/mature.fa")
species <- substr(names(mirbase), start = 1,stop = 3)
mirbase <- mirbase[-which(species != "mmu")]
mirna_seqs <- data.frame(mirna = names(mirbase), mirna_seq = names(mirbase))
for(n in 1:length(mirbase)){ mirna_seqs$mirna_seq[n] <- paste(mirbase[[n]], collapse = "")}

#Add sequences of miRNAs targetting differentially edited genes
MCMV_TarBase <- left_join(MCMV_TarBase, mirna_seqs, by = "mirna")
MCMV_TarBase$mirna_seq <- sapply(MCMV_TarBase$mirna_seq, toupper)
ZIKV_1_TarBase <- left_join(ZIKV_1_TarBase, mirna_seqs, by = "mirna")
ZIKV_1_TarBase$mirna_seq <- sapply(ZIKV_1_TarBase$mirna_seq, toupper)
ZIKV_358758_TarBase <- left_join(ZIKV_358758_TarBase, mirna_seqs, by = "mirna")
ZIKV_358758_TarBase$mirna_seq <- sapply(ZIKV_358758_TarBase$mirna_seq, toupper)




#==================================Get Gene/miRNA Expression Values and Format for SubmiRine==============================================
#MCMV
#read expression files
Ctrl_MCMV_1_exp <- read.delim("data/expression/MCMV/ERR4277226.tab", sep = "\t", header = T)
Ctrl_MCMV_2_exp <- read.delim("data/expression/MCMV/ERR4277227.tab", sep = "\t", header = T)
Ctrl_MCMV_3_exp <- read.delim("data/expression/MCMV/ERR4277228.tab", sep = "\t", header = T)
MCMV_inf_1_exp <- read.delim("data/expression/MCMV/ERR4277229.tab", sep = "\t", header = T)
MCMV_inf_2_exp <- read.delim("data/expression/MCMV/ERR4277230.tab", sep = "\t", header = T)
MCMV_inf_3_exp <- read.delim("data/expression/MCMV/ERR4277231.tab", sep = "\t", header = T)

#Calculate expression average expression values for infected/control samples
MCMV_ctrl_exp <- inner_join(Ctrl_MCMV_1_exp, Ctrl_MCMV_2_exp, by = "Gene.Name")
MCMV_ctrl_exp <- inner_join(MCMV_ctrl_exp, Ctrl_MCMV_3_exp, by = "Gene.Name")
MCMV_ctrl_exp$Ctrl_exp <- apply(MCMV_ctrl_exp[,c(9,17,25)],1,mean)
MCMV_inf_exp <- inner_join(MCMV_inf_1_exp, MCMV_inf_2_exp, by = "Gene.Name")
MCMV_inf_exp <- inner_join(MCMV_inf_exp, MCMV_inf_3_exp, by = "Gene.Name")
MCMV_inf_exp$MCMV_exp <- apply(MCMV_inf_exp[,c(9,17,25)],1,mean)

#Attach expression values to edited genes
#The condition with lower editing is considered "unedited" expression, and the condition with higher editing is considered "edited" expression
for(n in 1:nrow(MCMV_TarBase)){
  ctrl_ed <- mean(as.numeric(MCMV_TarBase[n,4:6]))
  mcmv_ed <- mean(as.numeric(MCMV_TarBase[n,7:9]))
  if(ctrl_ed < mcmv_ed){
    MCMV_TarBase$unedited_expression[n] <- MCMV_ctrl_exp$Ctrl_exp[which(MCMV_ctrl_exp$Gene.ID == MCMV_TarBase$geneId[n])]
    MCMV_TarBase$edited_expression[n] <- MCMV_inf_exp$MCMV_exp[which(MCMV_inf_exp$Gene.ID == MCMV_TarBase$geneId[n])]
  }
  else{
    MCMV_TarBase$edited_expression[n] <- MCMV_ctrl_exp$Ctrl_exp[which(MCMV_ctrl_exp$Gene.ID == MCMV_TarBase$geneId[n])]
    MCMV_TarBase$unedited_expression[n] <- MCMV_inf_exp$MCMV_exp[which(MCMV_inf_exp$Gene.ID == MCMV_TarBase$geneId[n])]
  }
}



#ZIKV 487357
#read expression files
Ctrl_1_1_exp <- read.delim("data/expression/ZIKV_487357/SRR7741202.tab", sep = "\t", header = T)
Ctrl_1_2_exp <- read.delim("data/expression/ZIKV_487357/SRR7741204.tab", sep = "\t", header = T)
Ctrl_1_3_exp <- read.delim("data/expression/ZIKV_487357/SRR7741206.tab", sep = "\t", header = T)
ZIKV_1_1_exp <- read.delim("data/expression/ZIKV_487357/SRR7741203.tab", sep = "\t", header = T)
ZIKV_1_2_exp <- read.delim("data/expression/ZIKV_487357/SRR7741205.tab", sep = "\t", header = T)
ZIKV_1_3_exp <- read.delim("data/expression/ZIKV_487357/SRR7741207.tab", sep = "\t", header = T)

#Calculate expression average expression values for infected/control samples
ZIKV_1_ctrl_exp <- inner_join(Ctrl_1_1_exp, Ctrl_1_2_exp, by = "Gene.Name")
ZIKV_1_ctrl_exp <- inner_join(ZIKV_1_ctrl_exp, Ctrl_1_3_exp, by = "Gene.Name")
ZIKV_1_ctrl_exp$Ctrl_exp <- apply(ZIKV_1_ctrl_exp[,c(9,17,25)],1,mean)
ZIKV_1_exp <- inner_join(ZIKV_1_1_exp, ZIKV_1_2_exp, by = "Gene.Name")
ZIKV_1_exp <- inner_join(ZIKV_1_exp, ZIKV_1_3_exp, by = "Gene.Name")
ZIKV_1_exp$ZIKV_exp <- apply(ZIKV_1_exp[,c(9,17,25)],1,mean)


#Attach expression values to edited genes
#The condition with lower editing is considered "unedited" expression, and the condition with higher editing is considered "edited" expression
for(n in 1:nrow(ZIKV_1_TarBase)){
  ctrl_ed <- mean(as.numeric(ZIKV_1_TarBase[n,c(4,6,8)]))
  zikv_ed <- mean(as.numeric(ZIKV_1_TarBase[n,c(5,7,9)]))
  if(ctrl_ed < zikv_ed){
    ZIKV_1_TarBase$unedited_expression[n] <- ZIKV_1_ctrl_exp$Ctrl_exp[which(ZIKV_1_ctrl_exp$Gene.ID == ZIKV_1_TarBase$geneId[n])]
    ZIKV_1_TarBase$edited_expression[n] <- ZIKV_1_exp$ZIKV_exp[which(ZIKV_1_exp$Gene.ID == ZIKV_1_TarBase$geneId[n])]
  }
  else{
    ZIKV_1_TarBase$edited_expression[n] <- ZIKV_1_ctrl_exp$Ctrl_exp[which(ZIKV_1_ctrl_exp$Gene.ID == ZIKV_1_TarBase$geneId[n])]
    ZIKV_1_TarBase$unedited_expression[n] <- ZIKV_1_exp$ZIKV_exp[which(ZIKV_1_exp$Gene.ID == ZIKV_1_TarBase$geneId[n])]
  }
}






#ZIKV 358758
#read expression files
Ctrl_358758_1_exp <- read.delim("data/expression/ZIKV_358758/SRR5136882.tab", sep = "\t", header = T)
Ctrl_358758_2_exp <- read.delim("data/expression/ZIKV_358758/SRR5136883.tab", sep = "\t", header = T)
Ctrl_358758_3_exp <- read.delim("data/expression/ZIKV_358758/SRR5137136.tab", sep = "\t", header = T)
ZIKV_358758_1_exp <- read.delim("data/expression/ZIKV_358758/SRR5137139.tab", sep = "\t", header = T)
ZIKV_358758_2_exp <- read.delim("data/expression/ZIKV_358758/SRR5137142.tab", sep = "\t", header = T)
ZIKV_358758_3_exp <- read.delim("data/expression/ZIKV_358758/SRR5137144.tab", sep = "\t", header = T)

#Calculate expression average expression values for infected/control samples
ZIKV_358758_ctrl_exp <- inner_join(Ctrl_358758_1_exp, Ctrl_358758_2_exp, by = "Gene.Name")
ZIKV_358758_ctrl_exp <- inner_join(ZIKV_358758_ctrl_exp, Ctrl_358758_3_exp, by = "Gene.Name")
ZIKV_358758_ctrl_exp$Ctrl_exp <- apply(ZIKV_358758_ctrl_exp[,c(9,17,25)],1,mean)
ZIKV_358758_exp <- inner_join(ZIKV_358758_1_exp, ZIKV_358758_2_exp, by = "Gene.Name")
ZIKV_358758_exp <- inner_join(ZIKV_358758_exp, ZIKV_358758_3_exp, by = "Gene.Name")
ZIKV_358758_exp$ZIKV_exp <- apply(ZIKV_358758_exp[,c(9,17,25)],1,mean)


#Attach expression values to edited genes
#The condition with lower editing is considered "unedited" expression, and the condition with higher editing is considered "edited" expression
for(n in 1:nrow(ZIKV_358758_TarBase)){
  ctrl_ed <- mean(as.numeric(ZIKV_358758_TarBase[n,c(4,6,8)]))
  zikv_ed <- mean(as.numeric(ZIKV_358758_TarBase[n,c(5,7,9)]))
  if(ctrl_ed < zikv_ed){
    ZIKV_358758_TarBase$unedited_expression[n] <- ZIKV_358758_ctrl_exp$Ctrl_exp[which(ZIKV_358758_ctrl_exp$Gene.ID == ZIKV_358758_TarBase$geneId[n])]
    ZIKV_358758_TarBase$edited_expression[n] <- ZIKV_358758_exp$ZIKV_exp[which(ZIKV_358758_exp$Gene.ID == ZIKV_358758_TarBase$geneId[n])]
  }
  else{
    ZIKV_358758_TarBase$edited_expression[n] <- ZIKV_358758_ctrl_exp$Ctrl_exp[which(ZIKV_358758_ctrl_exp$Gene.ID == ZIKV_358758_TarBase$geneId[n])]
    ZIKV_358758_TarBase$unedited_expression[n] <- ZIKV_358758_exp$ZIKV_exp[which(ZIKV_358758_exp$Gene.ID == ZIKV_358758_TarBase$geneId[n])]
  }
}





#Create an ID for each editing site/miRNA pair in the format required by SubmiRine
#MCMV
for(n in 1:nrow(MCMV_TarBase)){
  MCMV_TarBase$unedited_fasta_name[n] <- paste(str_trim(MCMV_TarBase$geneName.x[n]), "_", MCMV_TarBase$POS[n], "|unedited", " ", MCMV_TarBase$unedited_expression[n], sep = "")
}
for(n in 1:nrow(MCMV_TarBase)){
  MCMV_TarBase$edited_fasta_name[n] <- paste(str_trim(MCMV_TarBase$geneName.x[n]), "_", MCMV_TarBase$POS[n], "|edited", " ", MCMV_TarBase$edited_expression[n], sep = "")
}

#ZIKV 487357
for(n in 1:nrow(ZIKV_1_TarBase)){
  ZIKV_1_TarBase$unedited_fasta_name[n] <- paste(str_trim(ZIKV_1_TarBase$geneName.x[n]), "_", ZIKV_1_TarBase$POS[n], "|unedited", " ", ZIKV_1_TarBase$unedited_expression[n], sep = "")
}
for(n in 1:nrow(ZIKV_1_TarBase)){
  ZIKV_1_TarBase$edited_fasta_name[n] <- paste(str_trim(ZIKV_1_TarBase$geneName.x[n]), "_", ZIKV_1_TarBase$POS[n], "|edited", " ", ZIKV_1_TarBase$edited_expression[n], sep = "")
}

#ZIKV 358758
for(n in 1:nrow(ZIKV_358758_TarBase)){
  ZIKV_358758_TarBase$unedited_fasta_name[n] <- paste(str_trim(ZIKV_358758_TarBase$geneName.x[n]), "_", ZIKV_358758_TarBase$POS[n], "|unedited", " ", ZIKV_358758_TarBase$unedited_expression[n], sep = "")
}
for(n in 1:nrow(ZIKV_358758_TarBase)){
  ZIKV_358758_TarBase$edited_fasta_name[n] <- paste(str_trim(ZIKV_358758_TarBase$geneName.x[n]), "_", ZIKV_358758_TarBase$POS[n], "|edited", " ", ZIKV_358758_TarBase$edited_expression[n], sep = "")
}


#Get miRNA expression and format for SubmiRine
mirbase_ids <- miRNA_MatureToPrecursor(c(MCMV_TarBase$mirna,ZIKV_1_TarBase$mirna,ZIKV_358758_TarBase$mirna))[,2]
mirna_genes <- getBM(attributes=c("ensembl_gene_id", "mirbase_id"), filters=c("mirbase_id"), values=mirbase_ids, mart=mart, useCache = FALSE)

#MCMV
MCMV_mirna <- MCMV_TarBase$mirna %>% miRNA_MatureToPrecursor() %>% unique()
names(MCMV_mirna) <- c("mirna", "mirbase_id")
MCMV_mirna <- left_join(MCMV_mirna, data.frame(mirna = MCMV_TarBase$mirna, mirna_seq = MCMV_TarBase$mirna_seq),by = "mirna")
MCMV_mirna <- left_join(MCMV_mirna, mirna_genes, by = "mirbase_id")
MCMV_mirna <- left_join(MCMV_mirna, data.frame(ensembl_gene_id = MCMV_ctrl_exp$Gene.ID, Ctrl_exp = MCMV_ctrl_exp$Ctrl_exp), by = "ensembl_gene_id")
MCMV_mirna <- left_join(MCMV_mirna, data.frame(ensembl_gene_id = MCMV_inf_exp$Gene.ID, MCMV_exp = MCMV_inf_exp$MCMV_exp), by = "ensembl_gene_id")
MCMV_mirna <- mutate(MCMV_mirna, mirna_exp = (Ctrl_exp+MCMV_exp)/2)
MCMV_mirna <- MCMV_mirna[!duplicated(MCMV_mirna$mirbase_id),]

#ZIKV 487357
ZIKV_1_mirna <- ZIKV_1_TarBase$mirna %>% miRNA_MatureToPrecursor() %>% unique()
names(ZIKV_1_mirna) <- c("mirna", "mirbase_id")
ZIKV_1_mirna <- left_join(ZIKV_1_mirna, data.frame(mirna = ZIKV_1_TarBase$mirna, mirna_seq = ZIKV_1_TarBase$mirna_seq),by = "mirna")
ZIKV_1_mirna <- left_join(ZIKV_1_mirna, mirna_genes, by = "mirbase_id")
ZIKV_1_mirna <- left_join(ZIKV_1_mirna, data.frame(ensembl_gene_id = ZIKV_1_ctrl_exp$Gene.ID, Ctrl_exp = ZIKV_1_ctrl_exp$Ctrl_exp), by = "ensembl_gene_id")
ZIKV_1_mirna <- left_join(ZIKV_1_mirna, data.frame(ensembl_gene_id = ZIKV_1_exp$Gene.ID, ZIKV_exp = ZIKV_1_exp$ZIKV_exp), by = "ensembl_gene_id")
ZIKV_1_mirna <- mutate(ZIKV_1_mirna, mirna_exp = (Ctrl_exp+ZIKV_exp)/2)
ZIKV_1_mirna <- ZIKV_1_mirna[!duplicated(ZIKV_1_mirna$mirbase_id),]

#ZIKV 358758
ZIKV_358758_mirna <- ZIKV_358758_TarBase$mirna %>% miRNA_MatureToPrecursor() %>% unique()
names(ZIKV_358758_mirna) <- c("mirna", "mirbase_id")
ZIKV_358758_mirna <- left_join(ZIKV_358758_mirna, data.frame(mirna = ZIKV_358758_TarBase$mirna, mirna_seq = ZIKV_358758_TarBase$mirna_seq),by = "mirna")
ZIKV_358758_mirna <- left_join(ZIKV_358758_mirna, mirna_genes, by = "mirbase_id")
ZIKV_358758_mirna <- left_join(ZIKV_358758_mirna, data.frame(ensembl_gene_id = ZIKV_358758_ctrl_exp$Gene.ID, Ctrl_exp = ZIKV_358758_ctrl_exp$Ctrl_exp), by = "ensembl_gene_id")
ZIKV_358758_mirna <- left_join(ZIKV_358758_mirna, data.frame(ensembl_gene_id = ZIKV_358758_exp$Gene.ID, ZIKV_exp = ZIKV_358758_exp$ZIKV_exp), by = "ensembl_gene_id")
ZIKV_358758_mirna <- mutate(ZIKV_358758_mirna, mirna_exp = (Ctrl_exp+ZIKV_exp)/2)
ZIKV_358758_mirna <- ZIKV_358758_mirna[!duplicated(ZIKV_358758_mirna$mirbase_id),]
ZIKV_358758_mirna[is.na(ZIKV_358758_mirna)] <- 0

#Add SubmiRine miRNA IDs to dataframes
MCMV_mirna <- mutate(MCMV_mirna, mirna_fasta_name = paste(mirna, mirna_exp))
ZIKV_1_mirna <- mutate(ZIKV_1_mirna, mirna_fasta_name = paste(mirna, mirna_exp))
ZIKV_358758_mirna <- mutate(ZIKV_358758_mirna, mirna_fasta_name = paste(mirna, mirna_exp))
#Remove duplicate miRNA/Gene pairs
MCMV_TarBase <- MCMV_TarBase[!duplicated(MCMV_TarBase$edited_utr_3_seq),]
ZIKV_1_TarBase <- ZIKV_1_TarBase[!duplicated(ZIKV_1_TarBase$edited_utr_3_seq),]
ZIKV_358758_TarBase <- ZIKV_358758_TarBase[!duplicated(ZIKV_358758_TarBase$edited_utr_3_seq),]

#Create FASTA files to input to SubmiRine
write.fasta(sequences = as.list(c(MCMV_TarBase$utr_3_seq, MCMV_TarBase$edited_utr_3_seq)), names = c(MCMV_TarBase$unedited_fasta_name, MCMV_TarBase$edited_fasta_name), file.out = "output/submirine_input/MCMV_3utr.fa")
write.fasta(sequences = as.list(c(ZIKV_1_TarBase$utr_3_seq, ZIKV_1_TarBase$edited_utr_3_seq)), names = c(ZIKV_1_TarBase$unedited_fasta_name, ZIKV_1_TarBase$edited_fasta_name), file.out = "output/submirine_input/ZIKV_1_3utr.fa")
write.fasta(sequences = as.list(c(ZIKV_358758_TarBase$utr_3_seq, ZIKV_358758_TarBase$edited_utr_3_seq)), names = c(ZIKV_358758_TarBase$unedited_fasta_name, ZIKV_358758_TarBase$edited_fasta_name), file.out = "output/submirine_input/ZIKV_2_3utr.fa")

write.fasta(sequences = as.list(MCMV_mirna$mirna_seq), names = MCMV_mirna$mirna_fasta_name, file.out = "output/submirine_input/MCMV_mirna.fa")
write.fasta(sequences = as.list(ZIKV_1_mirna$mirna_seq), names = ZIKV_1_mirna$mirna_fasta_name, file.out = "output/submirine_input/ZIKV_1_mirna.fa")
write.fasta(sequences = as.list(ZIKV_358758_mirna$mirna_seq), names = ZIKV_358758_mirna$mirna_fasta_name, file.out = "output/submirine_input/ZIKV_2_mirna.fa")









