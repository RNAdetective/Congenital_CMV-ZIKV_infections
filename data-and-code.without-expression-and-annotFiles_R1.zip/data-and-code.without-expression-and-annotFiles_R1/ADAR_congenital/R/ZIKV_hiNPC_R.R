library(ggplot2)
library(dplyr)
library(stringr)
library(tidyr)
library(DESeq2)
source("R/editing_functions.R")


#Set working directory to "ADAR_congenital" project folder
setwd()



#=================Data processing and analysis==========================================




#Read REDIportal variant data
REDIportal <- read.delim("data/TABLE1_hg38.txt")
#Create a list of these coordinates, reference RNA editing sites
REDIcoordinates <- data.frame(Region = REDIportal$Region, Position = REDIportal$Position)




#Read in files with variants for each sample
Control_counts_1 <- read.table("data/frequency_counts/ZIKV_hiNPC/SRR9610802__readCountsIni100F.txt", sep = '\t', header = F, fill = T)                                  
Control_counts_1 <- Control_counts_1[,-c(5,10,11)]
names(Control_counts_1) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count")
Control_counts_1 <- drop_na(Control_counts_1, "TOTAL")
Control_counts_1 <- data.frame(Control_counts_1, Sample = rep("SRR9610802",nrow(Control_counts_1)), Infection = rep("Control",nrow(Control_counts_1)))
Control_counts_1 <- get_counts(Control_counts_1)
Control_counts_1 <- filter_ADAR(Control_counts_1, REDIcoordinates$Position)


Control_counts_2 <- read.table("data/frequency_counts/ZIKV_hiNPC/SRR9610803__readCountsIni100F.txt", sep = '\t', header = F, fill = T)
Control_counts_2 <- Control_counts_2[,-c(5,10,11)]
names(Control_counts_2) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count")
Control_counts_2 <- drop_na(Control_counts_2, "TOTAL")
Control_counts_2 <- data.frame(Control_counts_2, Sample = rep("SRR9610803",nrow(Control_counts_2)), Infection = rep("Control",nrow(Control_counts_2)))
Control_counts_2 <- get_counts(Control_counts_2)
Control_counts_2 <- filter_ADAR(Control_counts_2, REDIcoordinates$Position)


Control_counts_3 <- read.table("data/frequency_counts/ZIKV_hiNPC/SRR9610804__readCountsIni100F.txt", sep = '\t', header = F, fill = T)
Control_counts_3 <- Control_counts_3[,-c(5,10,11)]
names(Control_counts_3) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count")
Control_counts_3 <- drop_na(Control_counts_3, "TOTAL")
Control_counts_3 <- data.frame(Control_counts_3, Sample = rep("SRR9610804",nrow(Control_counts_3)), Infection = rep("Control",nrow(Control_counts_3)))
Control_counts_3 <- get_counts(Control_counts_3)
Control_counts_3 <- filter_ADAR(Control_counts_3, REDIcoordinates$Position)


ZIKV_FSS_counts_1 <- read.table("data/frequency_counts/ZIKV_hiNPC/SRR9610798__readCountsIni100F.txt", sep = '\t', header = F, fill = T)
ZIKV_FSS_counts_1 <- ZIKV_FSS_counts_1[,-c(5,10,11)]
names(ZIKV_FSS_counts_1) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count")
ZIKV_FSS_counts_1 <- drop_na(ZIKV_FSS_counts_1, "TOTAL")
ZIKV_FSS_counts_1 <- data.frame(ZIKV_FSS_counts_1, Sample = rep("SRR9610798",nrow(ZIKV_FSS_counts_1)), Infection = rep("ZIKV.FSS13205",nrow(ZIKV_FSS_counts_1)))
ZIKV_FSS_counts_1  <- get_counts(ZIKV_FSS_counts_1 )
ZIKV_FSS_counts_1 <- filter_ADAR(ZIKV_FSS_counts_1, REDIcoordinates$Position)


ZIKV_FSS_counts_2 <- read.table("data/frequency_counts/ZIKV_hiNPC/SRR9610799__readCountsIni100F.txt", sep = '\t', header = F, fill = T)
ZIKV_FSS_counts_2 <- ZIKV_FSS_counts_2[,-c(5,10,11)]
names(ZIKV_FSS_counts_2) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count")
ZIKV_FSS_counts_2 <- drop_na(ZIKV_FSS_counts_2, "TOTAL")
ZIKV_FSS_counts_2 <- data.frame(ZIKV_FSS_counts_2, Sample = rep("SRR9610799",nrow(ZIKV_FSS_counts_2)), Infection = rep("ZIKV.FSS13205",nrow(ZIKV_FSS_counts_2)))
ZIKV_FSS_counts_2 <- get_counts(ZIKV_FSS_counts_2)
ZIKV_FSS_counts_2 <- filter_ADAR(ZIKV_FSS_counts_2, REDIcoordinates$Position)


ZIKV_FSS_counts_3 <- read.table("data/frequency_counts/ZIKV_hiNPC/SRR9610805__readCountsIni100F.txt", sep = '\t', header = F, fill = T)
ZIKV_FSS_counts_3 <- ZIKV_FSS_counts_3[,-c(5,10,11)]
names(ZIKV_FSS_counts_3) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count")
ZIKV_FSS_counts_3 <- drop_na(ZIKV_FSS_counts_3, "TOTAL")
ZIKV_FSS_counts_3 <- data.frame(ZIKV_FSS_counts_3, Sample = rep("SRR9610805",nrow(ZIKV_FSS_counts_3)), Infection = rep("ZIKV.FSS13205",nrow(ZIKV_FSS_counts_3)))
ZIKV_FSS_counts_3 <- get_counts(ZIKV_FSS_counts_3)
ZIKV_FSS_counts_3 <- filter_ADAR(ZIKV_FSS_counts_3, REDIcoordinates$Position)


ZIKV_PE_counts_1 <- read.table("data/frequency_counts/ZIKV_hiNPC/SRR9610797__readCountsIni100F.txt", sep = '\t', header = F, fill = T)
ZIKV_PE_counts_1 <- ZIKV_PE_counts_1[,-c(5,10,11)]
names(ZIKV_PE_counts_1) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count")
ZIKV_PE_counts_1 <- drop_na(ZIKV_PE_counts_1, "TOTAL")
ZIKV_PE_counts_1 <- data.frame(ZIKV_PE_counts_1, Sample = rep("SRR9610797",nrow(ZIKV_PE_counts_1)), Infection = rep("ZIKV.PE243",nrow(ZIKV_PE_counts_1)))
ZIKV_PE_counts_1 <- get_counts(ZIKV_PE_counts_1)
ZIKV_PE_counts_1 <- filter_ADAR(ZIKV_PE_counts_1, REDIcoordinates$Position)


ZIKV_PE_counts_2 <- read.table("data/frequency_counts/ZIKV_hiNPC/SRR9610800__readCountsIni100F.txt", sep = '\t', header = F, fill = T)
ZIKV_PE_counts_2 <- ZIKV_PE_counts_2[,-c(5,10,11)]
names(ZIKV_PE_counts_2) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count")
ZIKV_PE_counts_2<- drop_na(ZIKV_PE_counts_2, "TOTAL")
ZIKV_PE_counts_2 <- data.frame(ZIKV_PE_counts_2, Sample = rep("SRR9610800",nrow(ZIKV_PE_counts_2)), Infection = rep("ZIKV.PE243",nrow(ZIKV_PE_counts_2)))
ZIKV_PE_counts_2 <- get_counts(ZIKV_PE_counts_2)
ZIKV_PE_counts_2 <- filter_ADAR(ZIKV_PE_counts_2, REDIcoordinates$Position)


ZIKV_PE_counts_3 <- read.table("data/frequency_counts/ZIKV_hiNPC/SRR9610801__readCountsIni100F.txt", sep = '\t', header = F, fill = T)
ZIKV_PE_counts_3 <- ZIKV_PE_counts_3[,-c(5,10,11)]
names(ZIKV_PE_counts_3) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count")
ZIKV_PE_counts_3 <- drop_na(ZIKV_PE_counts_3, "TOTAL")
ZIKV_PE_counts_3 <- data.frame(ZIKV_PE_counts_3, Sample = rep("SRR9610801",nrow(ZIKV_PE_counts_3)), Infection = rep("ZIKV.PE243",nrow(ZIKV_PE_counts_3)))
ZIKV_PE_counts_3 <- get_counts(ZIKV_PE_counts_3)
ZIKV_PE_counts_3 <- filter_ADAR(ZIKV_PE_counts_3, REDIcoordinates$Position)


ADAR_sites <- rbind(Control_counts_1,Control_counts_2,Control_counts_3,ZIKV_FSS_counts_1,ZIKV_FSS_counts_2,ZIKV_FSS_counts_3,ZIKV_PE_counts_1,ZIKV_PE_counts_2,ZIKV_PE_counts_3)

#Add site annotations from REDIportal
names(REDIportal)[2] <- "POS"
REDIportal <- REDIportal[,c(2,5,9,10,11)]
REDIportal <- REDIportal[!duplicated(REDIportal$POS), ]
ADAR_sites$POS <- as.integer(ADAR_sites$POS)
ADAR_sites <- left_join(ADAR_sites,REDIportal,by="POS")

#Create a dataframe to store whole-sample statistics
Sample_data <- data.frame(Sample = c("SRR9610802","SRR9610803","SRR9610804","SRR9610798",
                                     "SRR9610799","SRR9610805","SRR9610797","SRR9610800","SRR9610801"), Infection = c("Control",
                                                                               "Control","Control","ZIKV.FSS13205","ZIKV.FSS13205","ZIKV.FSS13205","ZIKV.PE243","ZIKV.PE243","ZIKV.PE243"))
#Add average editing rate to sample data
Sample_list <- split(ADAR_sites,ADAR_sites$Sample)
Sample_data <- editing_Average(Sample_list,Sample_data)

#Add number of editing sites to sample data
Sample_data <- data.frame(Sample_data, Editing.sites = summary(as.factor(ADAR_sites$Sample)))








#================================EXPRESSION====================================================

#Create files of TPM expression values for each sample
#Add labels for sample ID and infection condition
Control_TPM_1 <- read.table("data/expression/ZIKV_hiNPC/SRR9610802.tab", sep = '\t', header = T)
Control_TPM_1 <- Control_TPM_1[!duplicated(Control_TPM_1$Gene.ID), ]
Control_TPM_1 <- Control_TPM_1[!duplicated(Control_TPM_1$Gene.Name), ]
Control_TPM_1 <- data.frame(Control_TPM_1, Sample = rep("SRR9610802",nrow(Control_TPM_1)), Infection = rep("Control",nrow(Control_TPM_1)))

Control_TPM_2 <- read.table("data/expression/ZIKV_hiNPC/SRR9610803.tab", sep = '\t', header = T)
Control_TPM_2 <- Control_TPM_2[!duplicated(Control_TPM_2$Gene.ID), ]
Control_TPM_2 <- Control_TPM_2[!duplicated(Control_TPM_2$Gene.Name), ]
Control_TPM_2 <- data.frame(Control_TPM_2, Sample = rep("SRR9610803",nrow(Control_TPM_2)), Infection = rep("Control",nrow(Control_TPM_2)))

Control_TPM_3 <- read.table("data/expression/ZIKV_hiNPC/SRR9610804.tab", sep = '\t', header = T)
Control_TPM_3 <- Control_TPM_3[!duplicated(Control_TPM_3$Gene.ID), ]
Control_TPM_3 <- Control_TPM_3[!duplicated(Control_TPM_3$Gene.Name), ]
Control_TPM_3 <- data.frame(Control_TPM_3, Sample = rep("SRR9610804",nrow(Control_TPM_3)), Infection = rep("Control",nrow(Control_TPM_3)))

ZIKV_FSS_TPM_1 <- read.table("data/expression/ZIKV_hiNPC/SRR9610798.tab", sep = '\t', header = T)
ZIKV_FSS_TPM_1 <- ZIKV_FSS_TPM_1[!duplicated(ZIKV_FSS_TPM_1$Gene.ID), ]
ZIKV_FSS_TPM_1 <- ZIKV_FSS_TPM_1[!duplicated(ZIKV_FSS_TPM_1$Gene.Name), ]
ZIKV_FSS_TPM_1 <- data.frame(ZIKV_FSS_TPM_1, Sample = rep("SRR9610798",nrow(ZIKV_FSS_TPM_1)), Infection = rep("ZIKV.FSS13205",nrow(ZIKV_FSS_TPM_1)))

ZIKV_FSS_TPM_2 <- read.table("data/expression/ZIKV_hiNPC/SRR9610799.tab", sep = '\t', header = T)
ZIKV_FSS_TPM_2 <- ZIKV_FSS_TPM_2[!duplicated(ZIKV_FSS_TPM_2$Gene.ID), ]
ZIKV_FSS_TPM_2 <- ZIKV_FSS_TPM_2[!duplicated(ZIKV_FSS_TPM_2$Gene.Name), ]
ZIKV_FSS_TPM_2 <- data.frame(ZIKV_FSS_TPM_2, Sample = rep("SRR9610799",nrow(ZIKV_FSS_TPM_2)), Infection = rep("ZIKV.FSS13205",nrow(ZIKV_FSS_TPM_2)))

ZIKV_FSS_TPM_3 <- read.table("data/expression/ZIKV_hiNPC/SRR9610805.tab", sep = '\t', header = T)
ZIKV_FSS_TPM_3 <- ZIKV_FSS_TPM_3[!duplicated(ZIKV_FSS_TPM_3$Gene.ID), ]
ZIKV_FSS_TPM_3 <- ZIKV_FSS_TPM_3[!duplicated(ZIKV_FSS_TPM_3$Gene.Name), ]
ZIKV_FSS_TPM_3 <- data.frame(ZIKV_FSS_TPM_3, Sample = rep("SRR9610805",nrow(ZIKV_FSS_TPM_3)), Infection = rep("ZIKV.FSS13205",nrow(ZIKV_FSS_TPM_3)))

ZIKV_PE_TPM_1 <- read.table("data/expression/ZIKV_hiNPC/SRR9610797.tab", sep = '\t', header = T)
ZIKV_PE_TPM_1 <- ZIKV_PE_TPM_1[!duplicated(ZIKV_PE_TPM_1$Gene.ID), ]
ZIKV_PE_TPM_1 <- ZIKV_PE_TPM_1[!duplicated(ZIKV_PE_TPM_1$Gene.Name), ]
ZIKV_PE_TPM_1 <- data.frame(ZIKV_PE_TPM_1, Sample = rep("SRR9610797",nrow(ZIKV_PE_TPM_1)), Infection = rep("ZIKV.PE243",nrow(ZIKV_PE_TPM_1)))

ZIKV_PE_TPM_2 <- read.table("data/expression/ZIKV_hiNPC/SRR9610800.tab", sep = '\t', header = T)
ZIKV_PE_TPM_2 <- ZIKV_PE_TPM_2[!duplicated(ZIKV_PE_TPM_2$Gene.ID), ]
ZIKV_PE_TPM_2 <- ZIKV_PE_TPM_2[!duplicated(ZIKV_PE_TPM_2$Gene.Name), ]
ZIKV_PE_TPM_2 <- data.frame(ZIKV_PE_TPM_2, Sample = rep("SRR9610800",nrow(ZIKV_PE_TPM_2)), Infection = rep("ZIKV.PE243",nrow(ZIKV_PE_TPM_2)))

ZIKV_PE_TPM_3 <- read.table("data/expression/ZIKV_hiNPC/SRR9610801.tab", sep = '\t', header = T)
ZIKV_PE_TPM_3 <- ZIKV_PE_TPM_3[!duplicated(ZIKV_PE_TPM_3$Gene.ID), ]
ZIKV_PE_TPM_3 <- ZIKV_PE_TPM_3[!duplicated(ZIKV_PE_TPM_3$Gene.Name), ]
ZIKV_PE_TPM_3 <- data.frame(ZIKV_PE_TPM_3, Sample = rep("SRR9610801",nrow(ZIKV_PE_TPM_3)), Infection = rep("ZIKV.PE243",nrow(ZIKV_PE_TPM_3)))




#Create a combined dataframe with expression values for all samples
ZIKV_hiNPC_TPM_tot <- rbind(Control_TPM_1, Control_TPM_2, Control_TPM_3, ZIKV_FSS_TPM_1, ZIKV_FSS_TPM_2, ZIKV_FSS_TPM_3, ZIKV_PE_TPM_1, ZIKV_PE_TPM_2, ZIKV_PE_TPM_3)


#Get ADAR1/B1/B2 expression
ADAR_TPM <- ZIKV_hiNPC_TPM_tot[str_which(ZIKV_hiNPC_TPM_tot$Gene.Name, "ADAR"),]
ADAR_TPM <- split(ADAR_TPM, ADAR_TPM$Gene.Name)

#Add expression data for ADAR enzymes to sample data
ADAR_TPM[[1]] <- ADAR_TPM[[1]][,c(9,10)]
ADAR_TPM[[2]] <- ADAR_TPM[[2]][,c(9,10)]
ADAR_TPM[[3]] <- ADAR_TPM[[3]][,c(9,10)]
ADAR_TPM[[4]] <- ADAR_TPM[[4]][,c(9,10)]
names(ADAR_TPM[[1]])[1] <- "ADAR1.TPM"
names(ADAR_TPM[[2]])[1] <- "ADARB1.TPM"
names(ADAR_TPM[[3]])[1] <- "ADARB2.TPM"
names(ADAR_TPM[[4]])[1] <- "ADARB2_AS1.TPM"
Sample_data <- left_join(Sample_data, ADAR_TPM[[1]], by = "Sample")
Sample_data <- left_join(Sample_data, ADAR_TPM[[2]], by = "Sample")
Sample_data <- left_join(Sample_data, ADAR_TPM[[3]], by = "Sample")
Sample_data <- left_join(Sample_data, ADAR_TPM[[4]], by = "Sample")





#================================STATS====================================================

#Find sites with differential editing
coordinates <- ADAR_sites$POS[!duplicated(ADAR_sites$POS)]
Site_editing <- Site_sample_table(Sample_list,coordinates)
Site_editing <- Diff_editing_t_pairwise(Site_editing)
Site_editing <- left_join(Site_editing,REDIportal,by="POS")
Site_editing <- left_join(Site_editing, ADAR_sites[,1:3],by = "POS")
Site_editing <- Site_editing[!duplicated(Site_editing$POS), ]
Sig_sites <- filter(Site_editing, Site_editing$p.Control_ZIKV_FSS <= 0.05 | Site_editing$p.Control_ZIKV_PE <= 0.05 | Site_editing$p.ZIKV_FSS_ZIKV_PE  <= 0.05)

Sig_sites <- mutate(Sig_sites, Editing_change_ZIKV.PE_Ctrl = ((SRR9610797 + SRR9610800 + SRR9610801) - (SRR9610802 + SRR9610803 + SRR9610804))/3)
Sig_sites <- mutate(Sig_sites, Editing_change_ZIKV.FSS_Ctrl = ((SRR9610798 + SRR9610799 + SRR9610805) - (SRR9610802 + SRR9610803 + SRR9610804))/3)
Sig_sites <- mutate(Sig_sites, Editing_change_ZIKV.FSS_ZIKV.PE = ((SRR9610798 + SRR9610799 + SRR9610805) - (SRR9610797 + SRR9610800 + SRR9610801))/3)


ADAR1_exp_anova <- aov(ADAR1.TPM ~ Infection, data = Sample_data)
summary.aov(ADAR1_exp_anova)
tukey_ADAR1_TPM <- TukeyHSD(ADAR1_exp_anova, conf.level = 0.95)
tukey_ADAR1_TPM

ADARB1_exp_anova <- aov(ADARB1.TPM ~ Infection, data = Sample_data)
summary.aov(ADARB1_exp_anova)
tukey_ADARB1_TPM <- TukeyHSD(ADARB1_exp_anova, conf.level = 0.95)
tukey_ADARB1_TPM

ADARB2_exp_anova <- aov(ADARB2.TPM ~ Infection, data = Sample_data)
summary.aov(ADARB2_exp_anova)
tukey_ADARB2_TPM <- TukeyHSD(ADARB2_exp_anova, conf.level = 0.95)
tukey_ADARB2_TPM

Editing_site_anova <- aov(Editing.sites ~ Infection, data = Sample_data)
summary.aov(Editing_site_anova)
tukey_Editing_site <- TukeyHSD(Editing_site_anova, conf.level = 0.95)
tukey_Editing_site

Editing_ave_anova <- aov(Editing.average ~ Infection, data = Sample_data)
summary.aov(Editing_ave_anova)
tukey_Editing_ave <- TukeyHSD(Editing_ave_anova, conf.level = 0.95)
tukey_Editing_ave

# DESeq2
#Gene counts
# Read in count matrix from ballgown
gene_counts  <- read.csv("data/ballgown_counts/deseq2_PRJNA551246.human-ZIKV-NPC/gene_count_matrix.csv", header=T, row.names=1) 
# create experiment labels 
study_countsLabels <- read.csv("data/ballgown_counts/deseq2_PRJNA551246.human-ZIKV-NPC/PHENO_DATA.PRJNA551246.human-ZIKV-NPC.csv", header=T, row.names=1)
# create DESeq input matrix  
dds_study_gene <- DESeqDataSetFromMatrix(countData=gene_counts, colData = study_countsLabels, design = ~condition)
dds_gene <- DESeq(dds_study_gene)

#Pairwise comparisons for control vs. ZIKV_PE
results_DESeq2_PE_vs_Control_gene <- results(dds_gene, contrast = c("condition", "ZIKV_PE", "control"))
# Pairwise comparisons for control vs. ZIKV_FSS
results_DESeq2_FSS_vs_Control_gene <- results(dds_gene, contrast = c("condition", "ZIKV_FSS", "control"))
# Pairwise comparisons for ZIKV_PE vs. ZIKV_FSS
results_DESeq2_PE_vs_FSS_gene <- results(dds_gene, contrast = c("condition", "ZIKV_PE", "ZIKV_FSS"))

#Transcript counts
# Read in count matrix from ballgown
transcript_counts  <- read.csv("data/ballgown_counts/deseq2_PRJNA551246.human-ZIKV-NPC/transcript_count_matrix.csv", header=T, row.names=1) 
# create DESeq input matrix  
dds_study_transcript <- DESeqDataSetFromMatrix(countData=transcript_counts, colData = study_countsLabels, design = ~condition)
dds_transcript <- DESeq(dds_study_transcript)

#Pairwise comparisons for control vs. ZIKV_PE
results_DESeq2_PE_vs_Control_transcript <- results(dds_transcript, contrast = c("condition", "ZIKV_PE", "control"))
# Pairwise comparisons for control vs. ZIKV_FSS
results_DESeq2_FSS_vs_Control_transcript <- results(dds_transcript, contrast = c("condition", "ZIKV_FSS", "control"))
# Pairwise comparisons for ZIKV_PE vs. ZIKV_FSS
results_DESeq2_PE_vs_FSS_transcript <- results(dds_transcript, contrast = c("condition", "ZIKV_PE", "ZIKV_FSS"))









#RNA Editing Indexing
AEI_out <- read.csv("data/RNA_editing_index/ZIKV_hiNPC_EditingIndex.csv")
Sample_data <- left_join(Sample_data, AEI_out, by="Sample")

Index_anova <- aov(A2GEditingIndex ~ Infection, data = Sample_data)
summary.aov(Index_anova)
tukey_Editing_index <- TukeyHSD(Index_anova, conf.level = 0.95)
tukey_Editing_index




#================================PLOTS====================================================

#FIGURE 15
#Expression
ADAR1_plot <- ggplot(Sample_data, aes(y = ADAR1.TPM, x = Infection)) + geom_boxplot() + geom_jitter(shape=10, position=position_jitter(0.2)) + theme_classic(base_size = 25) + xlab(NULL) + ylab("ADAR Expression (TPM)") + geom_signif(comparisons = list(c("Control", "ZIKV.PE243"),c("Control", "ZIKV.FSS13205"),c("ZIKV.PE243", "ZIKV.FSS13205")), annotations = c("***","***","***"), y_position = c(290,250,270)) 
ADAR1_plot

ADARB1_plot <- ggplot(Sample_data, aes(y = ADARB1.TPM, x = Infection)) + geom_boxplot() + geom_jitter(shape=10, position=position_jitter(0.2)) + theme_classic(base_size = 25) + xlab(NULL) + ylab("ADARB1 Expression (TPM)") + geom_signif(comparisons = list(c("Control", "ZIKV.PE243"),c("Control", "ZIKV.FSS13205"),c("ZIKV.PE243", "ZIKV.FSS13205")), annotations = c("NS","NS","NS"), y_position = c(3.3,2.7,3))
ADARB1_plot

ADARB2_plot <- ggplot(Sample_data, aes(y = ADARB2.TPM, x = Infection)) + geom_boxplot() + geom_jitter(shape=10, position=position_jitter(0.2)) + theme_classic(base_size = 25) + xlab(NULL) + ylab("ADARB2 Expression (TPM)") + geom_signif(comparisons = list(c("Control", "ZIKV.PE243"),c("Control", "ZIKV.FSS13205"),c("ZIKV.PE243", "ZIKV.FSS13205")), annotations = c("NS","NS","NS"), y_position = c(.017,.013,.015))
ADARB2_plot

#FIGURE 16
#Editing sites boxplot
Ed_site_plot <- ggplot(Sample_data, aes(y = Editing.sites, x = Infection)) + geom_boxplot()  + geom_jitter(shape=10, position=position_jitter(0.2)) + theme_classic(base_size = 25) + xlab(NULL) + ylab("Editing Sites") + geom_signif(comparisons = list(c("Control", "ZIKV.PE243"),c("Control", "ZIKV.FSS13205"),c("ZIKV.PE243", "ZIKV.FSS13205")), annotations = c("NS","NS","NS"), y_position = c(210,190,200))
Ed_site_plot

#FIGURE 17
#Editing average boxplot
Ed_ave_plot <- ggplot(Sample_data, aes(y = Editing.average, x = Infection)) + geom_boxplot()  + geom_jitter(shape=10, position=position_jitter(0.2)) + theme_classic(base_size = 25) + xlab(NULL) + ylab("Average Editing Rate") + geom_signif(comparisons = list(c("Control", "ZIKV.PE243"),c("Control", "ZIKV.FSS13205"),c("ZIKV.PE243", "ZIKV.FSS13205")), annotations = c("NS","NS","NS"), y_position = c(0.47,.46,.465))
Ed_ave_plot

#FIGURE 18
#Editing
Ed_rate_plot <- ggplot(ADAR_sites, aes(y = Editing.rate, x = Sample, color = Infection)) + geom_violin() + geom_boxplot(width=0.1) + theme_classic(base_size = 25) +ylab("Editing Rate") + theme(text = element_text(size=15))
Ed_rate_plot





#Editing region plot
regions <- Sig_sites %>% dplyr::count(Func.wgEncodeGencodeBasicV34) 
regions <- regions[order(regions$n,decreasing=T),]
regions$Func.wgEncodeGencodeBasicV34 <- c("3' UTR", "Intergenic", "Intronic", "Exonic")
regions$Func.wgEncodeGencodeBasicV34 <- regions$Func.wgEncodeGencodeBasicV34 %>% factor(levels = c("3' UTR", "Exonic", "Intronic", "Intergenic"))
region_plot <- ggplot(data = regions, aes(x = "", y = n, fill = Func.wgEncodeGencodeBasicV34)) + labs(fill="Gene Region") + geom_bar(width = 1, stat = "identity") + coord_polar("y", start=0) + theme_void() + geom_text(aes(label = n), position = position_stack(vjust = 0.5))
region_plot






#RNA Editing Indexer
indeces <- Sample_data[,c("A2CEditingIndex","A2GEditingIndex","A2TEditingIndex","C2AEditingIndex","C2GEditingIndex","C2TEditingIndex")] %>% as.matrix() %>% as.vector()
variant <- c(rep("A-to-C",9),rep("A-to-G",9),rep("A-to-T",9),rep("C-to-A",9),rep("C-to-G",9),rep("C-to-T",9))

editing_index <- data.frame(Sample = rep(Sample_data$Sample, 6), Infection = rep(Sample_data$Infection, 6), 
                            Index = indeces, Variant = variant)

Ed_index_plot <- ggplot(editing_index, aes(y = Index, x = Variant, color = Infection)) + geom_boxplot() + geom_jitter(shape=10, position = position_jitterdodge(jitter.width = 0.2)) + theme_classic(base_size = 25) #+ xlab(NULL) + ylab("Editing Index") + geom_signif(comparisons = list(c("Control", "ZIKV.PE243"),c("Control", "ZIKV.FSS13205"),c("ZIKV.PE243", "ZIKV.FSS13205")), annotations = c("***","***","**")) 
Ed_index_plot



#Expression Editing correlation
colnames(Site_editing)[colnames(Site_editing) == "Gene.wgEncodeGencodeBasicV34"] ="Gene.Name"
site_exp <- left_join(Site_editing, data.frame(Gene.Name = Control_TPM_1$Gene.Name, Control_1_TPM = Control_TPM_1$TPM), by = "Gene.Name")
site_exp <- left_join(site_exp, data.frame(Gene.Name = Control_TPM_2$Gene.Name, Control_2_TPM = Control_TPM_2$TPM), by = "Gene.Name")
site_exp <- left_join(site_exp, data.frame(Gene.Name = Control_TPM_3$Gene.Name, Control_3_TPM = Control_TPM_3$TPM), by = "Gene.Name")
site_exp <- left_join(site_exp, data.frame(Gene.Name = ZIKV_FSS_TPM_1$Gene.Name, ZIKV_FSS_1_TPM = ZIKV_FSS_TPM_1$TPM), by = "Gene.Name")
site_exp <- left_join(site_exp, data.frame(Gene.Name = ZIKV_FSS_TPM_2$Gene.Name, ZIKV_FSS_2_TPM = ZIKV_FSS_TPM_2$TPM), by = "Gene.Name")
site_exp <- left_join(site_exp, data.frame(Gene.Name = ZIKV_FSS_TPM_3$Gene.Name, ZIKV_FSS_3_TPM = ZIKV_FSS_TPM_3$TPM), by = "Gene.Name")
site_exp <- left_join(site_exp, data.frame(Gene.Name = ZIKV_PE_TPM_1$Gene.Name, ZIKV_PE_1_TPM = ZIKV_PE_TPM_1$TPM), by = "Gene.Name")
site_exp <- left_join(site_exp, data.frame(Gene.Name = ZIKV_PE_TPM_2$Gene.Name, ZIKV_PE_2_TPM = ZIKV_PE_TPM_2$TPM), by = "Gene.Name")
site_exp <- left_join(site_exp, data.frame(Gene.Name = ZIKV_PE_TPM_3$Gene.Name, ZIKV_PE_3_TPM = ZIKV_PE_TPM_3$TPM), by = "Gene.Name")

exp_change <- mutate(site_exp, TPM_change_ZIKV.PE_Ctrl = ((ZIKV_PE_1_TPM + ZIKV_PE_2_TPM + ZIKV_PE_3_TPM) - (Control_1_TPM + Control_2_TPM + Control_3_TPM))/3)
exp_change <- mutate(exp_change, TPM_change_ZIKV.FSS_Ctrl = ((ZIKV_FSS_1_TPM + ZIKV_FSS_2_TPM + ZIKV_FSS_3_TPM) - (Control_1_TPM + Control_2_TPM + Control_3_TPM))/3)

exp_change <- mutate(exp_change, Editing_change_ZIKV.PE_Ctrl = ((SRR9610797 + SRR9610800 + SRR9610801) - (SRR9610802 + SRR9610803 + SRR9610804))/3)
exp_change <- mutate(exp_change, Editing_change_ZIKV.FSS_Ctrl = ((SRR9610798 + SRR9610799 + SRR9610805) - (SRR9610802 + SRR9610803 + SRR9610804))/3)


exp_edit_plot_PE <- ggplot(data = exp_change, aes(x = TPM_change_ZIKV.PE_Ctrl, y = Editing_change_ZIKV.PE_Ctrl)) + geom_point() + theme_classic() + xlab("Control-ZIKV PE243 TPM Change") + ylab("Control-ZIKV PE243 Editing Change")
exp_edit_plot_PE

exp_edit_plot_FSS <- ggplot(data = exp_change, aes(x = TPM_change_ZIKV.FSS_Ctrl, y = Editing_change_ZIKV.FSS_Ctrl)) + geom_point() + theme_classic() + xlab("Control-ZIKV FSS13205 TPM Change") + ylab("Control-ZIKV FSS13205 Editing Change") 
exp_edit_plot_FSS

exp_edit_cor_PE <- lm(data = exp_change, Editing_change_ZIKV.PE_Ctrl ~ TPM_change_ZIKV.PE_Ctrl)
summary(exp_edit_cor_PE)

exp_edit_cor_FSS <- lm(data = exp_change, Editing_change_ZIKV.FSS_Ctrl ~ TPM_change_ZIKV.FSS_Ctrl)
summary(exp_edit_cor_FSS)


#Volcano plot
exp_change <- mutate(exp_change, logp_Control_ZIKV_PE = -log10(p.Control_ZIKV_PE)) 
exp_change <- mutate(exp_change, logp_Control_ZIKV_FSS = -log10(p.Control_ZIKV_FSS))
vplot_PE <- ggplot(data = exp_change, aes(x = Editing_change_ZIKV.PE_Ctrl, y = logp_Control_ZIKV_PE, color = p.Control_ZIKV_PE < 0.05)) + geom_point() + theme_classic()+ xlab("Control-ZIKV PE243 Change in Editing Rate") + ylab("Control-ZIKV PE243 -log(p)") + labs(color = "") + scale_color_hue(labels = c("Significant", "Not significant"), breaks = c(TRUE, FALSE))
vplot_PE
vplot_FSS <- ggplot(data = exp_change, aes(x = Editing_change_ZIKV.FSS_Ctrl, y = logp_Control_ZIKV_FSS, color = p.Control_ZIKV_FSS < 0.05)) + geom_point() + theme_classic() + xlab("Control-ZIKV FSS13205 Change in Editing Rate") + ylab("Control-ZIKV FSS13205 -log(p)") + labs(color = "") + scale_color_hue(labels = c("Significant", "Not significant"), breaks = c(TRUE, FALSE))
vplot_FSS





















