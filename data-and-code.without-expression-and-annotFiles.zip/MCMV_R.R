library(ggplot2)
library(dplyr)
library(stringr)
library(tidyr)




#================================FUNCTIONS===================================================

#Filtering function, assumes labels "REF", "TOTAL", "A/C/T/G.count"
#Filtering criteria: A/T reference, in REDIportal, >3 reads, <.99 editing, not .5 editing
filter_ADAR <- function(reads, reference){
  
  #Select ADAR editing sites
  filtered <- filter(reads, REF == "T" | REF == "A")
  #attach editing frequency column
  filtered <- mutate(filtered, Editing.rate = 0)
  #Calculate editing frequency for each site: distinguishes between A->G and T->c
  for (n in 1:nrow(filtered)){
    if (filtered$REF[n] == "A"){
      filtered$Editing.rate[n] = filtered$G.count[n]/filtered$TOTAL[n]
    }
    else{
      filtered$Editing.rate[n] = filtered$C.count[n]/filtered$TOTAL[n]
    }
  }
  
  
  filtered <- filter(filtered, POS %in% reference)
  filtered <- filter(filtered, TOTAL >= 3)
  filtered <- filter(filtered, Editing.rate <= .99 & Editing.rate >= 0.01)
  filtered <- filter(filtered, Editing.rate <= .49 | Editing.rate >= 0.51)
  
  return(filtered)
}

#Function to add the average editing rate for each sample
editing_Average <- function(sample_List, sample_Data){
  y <- ncol(sample_Data) + 1
  Editing.average <- vector()
  for(m in 1:length(sample_List)){
    a <-  mean(sample_List[[m]]$Editing.rate)
    Editing.average <- c(Editing.average, a)
    
  }
  sample_Data <- cbind(sample_Data, Editing.average)
  
  return(sample_Data)
}




#Input a list containing each sample's editing sites, and a vector with each unique coordinate tested
#Output is a dataframe with editing rates in each sample for each coordinate (with sites with no variants detected automatically given as 0)
Site_sample_table <- function(Sample_list, Sites){
  zero <- rep(0,length(Sites))
  
  for(n in 1:length(Sample_list)){
    Sites <- data.frame(Sites,zero)
    
  }
  colnames(Sites) <- c("POS", names(Sample_list))
  
  for(n in 1:nrow(Sites)){
    for(m in 1:length(Sample_list)){
      if(Sites$POS[n] %in% Sample_list[[m]]$POS){
        Sites[n, m+1] <- Sample_list[[m]]$Editing.rate[match(Sites$POS[n], Sample_list[[m]]$POS)]
      } 
    }
  }
  
  return(Sites)
}




#Input a dataframe with editing rates for each sample per coordinate (as per the Site_sample_table() function)
#Adds a column with 
Diff_editing_t <- function(Site_editing){
  Site_editing <- mutate(Site_editing, p.value = 1)
  for(n in 1:nrow(Site_editing)){
    Site_editing$p.value[n] <- t.test(Site_editing[n, 2:4], Site_editing[n, 5:7])$p.value
  }
  Site_editing$p.value <- p.adjust(Site_editing$p.value, method='fdr')
  
  
  return(Site_editing)
}






#=================Data processing and analysis==========================================







#Read REDIportal variant data
REDIportal <- read.delim("/data/TABLE1_mm10.txt")
#Only non-dbsnp sites
REDIcoordinates <- filter(REDIportal, dbsnp == "-")
#Create a list of these coordinates, reference RNA editing sites
REDIcoordinates <- data.frame(REDIcoordinates$Region, REDIcoordinates$Position)


#Create files of variant frequency counts for each sample
#Add labels for sample ID and infection condition
Control_counts_1 <- read.csv("/data/frequency_counts/MCMV/ERR4277226All.csv")
Control_counts_1 <- data.frame(Control_counts_1, Sample = rep("ERR4277226",nrow(Control_counts_1)), Infection = rep("Control",nrow(Control_counts_1)))
names(Control_counts_1) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count","Sample","Infection")
Control_counts_1 <- filter_ADAR(Control_counts_1, REDIcoordinates$REDIcoordinates.Position)

Control_counts_2 <- read.csv("/data/frequency_counts/MCMV/ERR4277227All.csv")
Control_counts_2 <- data.frame(Control_counts_2, Sample = rep("ERR4277227",nrow(Control_counts_2)), Infection = rep("Control",nrow(Control_counts_2)))
names(Control_counts_2) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count","Sample","Infection")
Control_counts_2 <- filter_ADAR(Control_counts_2, REDIcoordinates$REDIcoordinates.Position)

Control_counts_3 <- read.csv("/data/frequency_counts/MCMV/ERR4277228All.csv")
Control_counts_3 <- data.frame(Control_counts_3, Sample = rep("ERR4277228",nrow(Control_counts_3)), Infection = rep("Control",nrow(Control_counts_3)))
names(Control_counts_3) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count","Sample","Infection")
Control_counts_3 <- filter_ADAR(Control_counts_3, REDIcoordinates$REDIcoordinates.Position)

MCMV_counts_1 <- read.csv("/data/frequency_counts/MCMV/ERR4277229All.csv")
MCMV_counts_1 <- data.frame(MCMV_counts_1, Sample = rep("ERR4277229",nrow(MCMV_counts_1)), Infection = rep("MCMV",nrow(MCMV_counts_1)))
names(MCMV_counts_1) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count","Sample","Infection")
MCMV_counts_1 <- filter_ADAR(MCMV_counts_1, REDIcoordinates$REDIcoordinates.Position)

MCMV_counts_2 <- read.csv("/data/frequency_counts/MCMV/ERR4277230All.csv")
MCMV_counts_2 <- data.frame(MCMV_counts_2, Sample = rep("ERR4277230",nrow(MCMV_counts_2)), Infection = rep("MCMV",nrow(MCMV_counts_2)))
names(MCMV_counts_2) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count","Sample","Infection")
MCMV_counts_2 <- filter_ADAR(MCMV_counts_2, REDIcoordinates$REDIcoordinates.Position)

MCMV_counts_3 <- read.csv("/data/frequency_counts/MCMV/ERR4277231All.csv")
MCMV_counts_3 <- data.frame(MCMV_counts_3, Sample = rep("ERR4277231",nrow(MCMV_counts_3)), Infection = rep("MCMV",nrow(MCMV_counts_3)))
names(MCMV_counts_3) <- c("CHR","POS","REF","TOTAL","A.count","C.count","G.count","T.count","Sample","Infection")
MCMV_counts_3 <- filter_ADAR(MCMV_counts_3, REDIcoordinates$REDIcoordinates.Position)

#Combine the above datasets into a single dataframe
ADAR_sites <- rbind(Control_counts_1,Control_counts_2,Control_counts_3,MCMV_counts_1,MCMV_counts_2,MCMV_counts_3)



#Add site annotations from REDIportal
names(REDIportal)[2] <- "POS"
REDIportal <- REDIportal[,c(2,5,9,10,11)]
ADAR_sites <- left_join(ADAR_sites,REDIportal,by="POS")

#Create a dataframe to store whole-sample statistics
Sample_data <- data.frame(Sample = c("ERR4277226","ERR4277227","ERR4277228","ERR4277229",
                                     "ERR4277230","ERR4277231"), Infection = c("Control",
                                                                               "Control","Control","MCMV","MCMV","MCMV"))

#Add average editing rate to sample data
Sample_list <- split(ADAR_sites,ADAR_sites$Sample)
Sample_data <-editing_Average(Sample_list,Sample_data)

#Add number of editing sites to sample data
Sample_data<-data.frame(Sample_data, Editing_sites = summary(as.factor(ADAR_sites$Sample)))





#================================EXPRESSION====================================================

#Create files of TPM expression values for each sample
#Add labels for sample ID and infection condition

Control_1 <- read.table(
  "/data/expression/ERR4277226.tab",
  sep="\t", header=TRUE)
Control_1 <- Control_1[!duplicated(Control_1$Gene.ID), ]
Control_1 <- Control_1[!duplicated(Control_1$Gene.Name), ]
Control_1 <- data.frame(Control_1, Sample = rep("ERR4277226",nrow(Control_1)), Infection = rep("Control",nrow(Control_1)))


Control_2 <- read.table(
  "/data/expression/ERR4277227.tab",
  sep="\t", header=TRUE)
Control_2 <- Control_2[!duplicated(Control_2$Gene.ID), ]
Control_2 <- Control_2[!duplicated(Control_2$Gene.Name), ]
Control_2 <- data.frame(Control_2, Sample = rep("ERR4277227",nrow(Control_2)), Infection = rep("Control",nrow(Control_2)))


Control_3 <- read.table(
  "/data/expression/ERR4277228.tab",
  sep="\t", header=TRUE)
Control_3 <- Control_3[!duplicated(Control_3$Gene.ID), ]
Control_3 <- Control_3[!duplicated(Control_3$Gene.Name), ]
Control_3 <- data.frame(Control_3, Sample = rep("ERR4277228",nrow(Control_3)), Infection = rep("Control",nrow(Control_3)))


MCMV_1 <- read.table(
  "/data/expression/ERR4277229.tab",
  sep="\t", header=TRUE)
MCMV_1 <- MCMV_1[!duplicated(MCMV_1$Gene.ID), ]
MCMV_1 <- MCMV_1[!duplicated(MCMV_1$Gene.Name), ]
MCMV_1 <- data.frame(MCMV_1, Sample = rep("ERR4277229",nrow(MCMV_1)), Infection = rep("MCMV",nrow(MCMV_1)))


MCMV_2 <- read.table(
  "/data/expression/ERR4277230.tab",
  sep="\t", header=TRUE)
MCMV_2 <- MCMV_2[!duplicated(MCMV_2$Gene.ID), ]
MCMV_2 <- MCMV_2[!duplicated(MCMV_2$Gene.Name), ]
MCMV_2 <- data.frame(MCMV_2, Sample = rep("ERR4277230",nrow(MCMV_2)), Infection = rep("MCMV",nrow(MCMV_2)))


MCMV_3 <- read.table(
  "/data/expression/ERR4277231.tab",
  sep="\t", header=TRUE)
MCMV_3 <- MCMV_3[!duplicated(MCMV_3$Gene.ID), ]
MCMV_3 <- MCMV_3[!duplicated(MCMV_3$Gene.Name), ]
MCMV_3 <- data.frame(MCMV_3, Sample = rep("ERR4277231",nrow(MCMV_3)), Infection = rep("MCMV",nrow(MCMV_3)))


#Create a combined dataframe with expression values for all samples
MCMV_TPM_tot <- rbind(Control_1, Control_2, Control_3, MCMV_1, MCMV_2, MCMV_3)


#Get ADAR1/b1/b2 expression
ADAR_TPM <- MCMV_TPM_tot[str_which(MCMV_TPM_tot$Gene.Name, "Adar"),]
ADAR_TPM <- split(ADAR_TPM, ADAR_TPM$Gene.Name)

#Add expression data for ADAR enzymes to sample data
ADAR_TPM[[1]] <- ADAR_TPM[[1]][,c(9,10)]
ADAR_TPM[[2]] <- ADAR_TPM[[2]][,c(9,10)]
ADAR_TPM[[3]] <- ADAR_TPM[[3]][,c(9,10)]
names(ADAR_TPM[[1]])[1] <- "Adar1.TPM"
names(ADAR_TPM[[2]])[1] <- "Adarb1.TPM"
names(ADAR_TPM[[3]])[1] <- "Adarb2.TPM"
Sample_data <- left_join(Sample_data, ADAR_TPM[[1]], by = "Sample")
Sample_data <- left_join(Sample_data, ADAR_TPM[[2]], by = "Sample")
Sample_data <- left_join(Sample_data, ADAR_TPM[[3]], by = "Sample")




#================================STATS===================================================

#ADAR1 expression
t.test(Sample_data$Adar1.TPM[1:3], Sample_data$Adar1.TPM[4:6])

#ADAR2 expression
t.test(Sample_data$Adarb1.TPM[1:3], Sample_data$Adarb1.TPM[4:6])

#ADAR3 expression
t.test(Sample_data$Adarb2.TPM[1:3], Sample_data$Adarb2.TPM[4:6])

#Site number
t.test(Sample_data$Editing_sites[1:3], Sample_data$Editing_sites[4:6])

#Average rate
t.test(Sample_data$Editing.average[1:3], Sample_data$Editing.average[4:6])




#Find sites with differential editing
coordinates <- ADAR_sites$POS[!duplicated(ADAR_sites$POS)]
Site_editing <- Site_sample_table(Sample_list, coordinates)
Site_editing <- Diff_editing_t(Site_editing)
Sig_sites <- filter(Site_editing, p.value <= 0.05)
Sig_sites <- left_join(Sig_sites,REDIportal,by="POS")
Site_editing <- left_join(Site_editing,REDIportal,by="POS")



#================================PLOTS====================================================



#Editing average boxplot
Ed_ave_plot <- ggplot(Sample_data, aes(y = Editing.average, x = Infection)) + geom_boxplot() + geom_jitter(shape=10, position=position_jitter(0.2)) + theme_classic(base_size = 25) + xlab(NULL) + ylab("Average Editing Rate") + geom_signif(comparisons = list(c("Control", "MCMV")), map_signif_level=TRUE, annotations = c("*"))
Ed_ave_plot

#Editing sites boxplot
Ed_site_plot <- ggplot(Sample_data, aes(y = Editing_sites, x = Infection)) + geom_boxplot() + geom_jitter(shape=10, position=position_jitter(0.2)) + theme_classic(base_size = 25) + xlab(NULL) + ylab("Editing Sites") + geom_signif(comparisons = list(c("Control", "MCMV")), map_signif_level=TRUE, annotations = c("*"))
Ed_site_plot

#Editing
Ed_rate_plot <- ggplot(ADAR_sites, aes(y = Editing.rate, x = Sample, color = Infection)) + geom_violin() + geom_boxplot(width=0.1) + theme_classic(base_size = 25) +ylab("Editing Rate")
Ed_rate_plot



#Expression
ADAR1_plot <- ggplot(Sample_data, aes(y = Adar1.TPM, x = Infection)) + geom_boxplot() + geom_jitter(shape=10, position=position_jitter(0.2)) + theme_classic(base_size = 25) + xlab(NULL) + ylab("Adar Expression (TPM)") + geom_signif(comparisons = list(c("Control", "MCMV")), map_signif_level=TRUE, annotations = c("**"))
ADAR1_plot

ADAR2_plot <- ggplot(Sample_data, aes(y = Adarb1.TPM, x = Infection)) + geom_boxplot() + geom_jitter(shape=10, position=position_jitter(0.2)) + theme_classic(base_size = 25) + xlab(NULL) + ylab("Adarb1 Expression (TPM)") + geom_signif(comparisons = list(c("Control", "MCMV")), map_signif_level=TRUE, annotations = c("NS"))
ADAR2_plot

ADAR3_plot <- ggplot(Sample_data, aes(y = Adarb2.TPM, x = Infection)) + geom_boxplot() + geom_jitter(shape=10, position=position_jitter(0.2)) + theme_classic(base_size = 25) + xlab(NULL) + ylab("Adarb2 Expression (TPM)") + geom_signif(comparisons = list(c("Control", "MCMV")), map_signif_level=TRUE, annotations = c("NS"))
ADAR3_plot






